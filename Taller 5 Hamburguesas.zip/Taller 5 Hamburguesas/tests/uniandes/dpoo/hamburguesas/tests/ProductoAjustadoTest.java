package uniandes.dpoo.hamburguesas.tests;

import static org.junit.jupiter.api.Assertions.*;


import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import uniandes.dpoo.hamburguesas.mundo.ProductoAjustado;
import uniandes.dpoo.hamburguesas.mundo.ProductoMenu;

class ProductoAjustadoTest {
	ProductoAjustado productoAjustado;
	
	@BeforeEach
	void setUp() {
		ProductoMenu productoBase = new ProductoMenu("Corral", 14000);
		productoAjustado = new ProductoAjustado(productoBase);
		
	}

	@Test
	void testGetNombre() {
        assertEquals( "Corral", productoAjustado.getNombre( ), "El nombre del producto no es el esperado." );

	}
	
	@Test
	void testGetPrecio() {
        assertEquals( 14000, productoAjustado.getPrecio( ), "El precio del producto no es el esperado." );
	}
	
	@Test
	void testGenerarTextoFactura() {
        assertEquals( "Corral\n            14000\n", productoAjustado.generarTextoFactura() , "El texto de la factura no es el esperado." );
	}	
	
	// No se implementaron pruebas para las funcionalidades de agregar y quitar ingredientes dado que de plano no existen.
}
