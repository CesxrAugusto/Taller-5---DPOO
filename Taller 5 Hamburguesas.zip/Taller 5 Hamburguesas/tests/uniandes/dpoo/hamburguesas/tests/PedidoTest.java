package uniandes.dpoo.hamburguesas.tests;

import static org.junit.jupiter.api.Assertions.*;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import uniandes.dpoo.hamburguesas.mundo.Pedido;
import uniandes.dpoo.hamburguesas.mundo.ProductoMenu;

class PedidoTest {
	    private Pedido pedido;
	    private ProductoMenu producto1;
	    private ProductoMenu producto2;

	    @BeforeEach
	    public void setUp() {
	        pedido = new Pedido("Cesar Espinosa", "Calle 127");
	        producto1 = new ProductoMenu("corral", 14000);
	        producto2 = new ProductoMenu("wrap de pollo", 15000);
	    }
	    @Test
	    public void testGetIdPedido() {
	        assertEquals(1, pedido.getIdPedido(), "El id del pedido no es el esperado");
	    }  
	    @Test
	    public void testGetNombreCliente() {
	        assertEquals("Cesar Espinosa", pedido.getNombreCliente(), "El nombre del cliente en el pedido no es el esperado");
	    }
	    @Test
	    public void testAgregarProducto() {
	    	// Acá se utilizó la función getProductos. Esta función no está implementada, pero debería estarlo.
	    	// Además, sin esta función es imposible verificar que la función agregarProductos está correctamente construida.
	        pedido.agregarProducto(producto1);
	        assertEquals(1, pedido.getProductos().size(), "El pedido debería tener al menos un producto");
	        assertEquals(producto1, pedido.getProductos().get(0), "El producto en el pedido no es el esperado");
	    }
	    @Test
	    public void testGetPrecioTotalPedido() {
	        pedido.agregarProducto(producto1);
	        pedido.agregarProducto(producto2);
	        assertEquals((int) (29000*1.19), pedido.getPrecioTotalPedido(), "El precio total del pedido no es el esperado.");
	    }
	    @Test
	    public void testGenerarTextoFactura() {
	        pedido.agregarProducto(producto1);
	        pedido.agregarProducto(producto2);
	        String textoFactura = pedido.generarTextoFactura();
	        
	        StringBuilder facturaEsperada = new StringBuilder();
	        facturaEsperada.append("Cliente: César Espinosa\n");
	        facturaEsperada.append("Dirección: Calle 127\n");
	        facturaEsperada.append("----------------\n");
	        facturaEsperada.append(producto1.generarTextoFactura());
	        facturaEsperada.append(producto2.generarTextoFactura());
	        facturaEsperada.append("----------------\n");
	        facturaEsperada.append("Precio Neto:  " + 29000 + "\n");
	        facturaEsperada.append("IVA:          " + ((int) (29000*0.19)) + "\n");
	        facturaEsperada.append("Precio Total: " + pedido.getPrecioTotalPedido() + "\n");

	        assertEquals(facturaEsperada.toString(), textoFactura, "La factura generada no es la esperada");
	    }

	    @Test
	    public void testGuardarFactura() throws FileNotFoundException {
	        File archivo = new File("factura.txt");
	        pedido.agregarProducto(producto1);
	        pedido.agregarProducto(producto2);
	        pedido.guardarFactura(archivo);

	        StringBuilder contenidoArchivo = new StringBuilder();
	        try (Scanner scanner = new Scanner(archivo)) {
	            while (scanner.hasNextLine()) {
	                contenidoArchivo.append(scanner.nextLine()).append("\n");
	            }
	        }

	        assertEquals(pedido.generarTextoFactura(), contenidoArchivo.toString(), "El contenido del archivo no es el esperado");

	        archivo.delete();
	}

}
