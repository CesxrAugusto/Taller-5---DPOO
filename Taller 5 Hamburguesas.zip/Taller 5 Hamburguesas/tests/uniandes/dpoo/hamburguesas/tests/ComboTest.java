package uniandes.dpoo.hamburguesas.tests;

import static org.junit.jupiter.api.Assertions.*;

import java.util.ArrayList;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import uniandes.dpoo.hamburguesas.mundo.Combo;
import uniandes.dpoo.hamburguesas.mundo.ProductoMenu;

class ComboTest {
	private Combo combo;
	
	@BeforeEach
	void SetUp() {
		ProductoMenu corral = new ProductoMenu("corral", 14000);
		ProductoMenu papasMedianas = new ProductoMenu("papas medianas", 5500);
		ProductoMenu gaseosa = new ProductoMenu("gaseosa", 5000);
		ArrayList<ProductoMenu> items = new ArrayList<ProductoMenu>();
		items.add(gaseosa);
		items.add(papasMedianas);
		items.add(corral);
		
		combo = new Combo("corral", 0.1, items);
	}

	@Test
	void testGetNombre() {
		assertEquals("combo corral", combo.getNombre(), "El nombre obtenido no es el esperado.");
	}
	
	@Test
	void testGetPrecio() {
		assertEquals(22050, combo.getPrecio(), "El precio obtenido no es el esperado.");
	}
	
	@Test
	void testGenerarTextoFactura() {
		assertEquals("Combo corral\n Descuento: 0.9\n            22050\n", combo.generarTextoFactura(), "La factura generada no es la esperada.");
	}
}
