package uniandes.dpoo.hamburguesas.tests;

import static org.junit.jupiter.api.Assertions.*;

import java.io.File;
import java.io.IOException;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import uniandes.dpoo.hamburguesas.excepciones.HamburguesaException;
import uniandes.dpoo.hamburguesas.excepciones.NoHayPedidoEnCursoException;
import uniandes.dpoo.hamburguesas.excepciones.YaHayUnPedidoEnCursoException;
import uniandes.dpoo.hamburguesas.mundo.Pedido;
import uniandes.dpoo.hamburguesas.mundo.Restaurante;

class RestauranteTest {
	private Restaurante restaurante;
	
	@BeforeEach
	void setUp() throws HamburguesaException, NumberFormatException, IOException {
		restaurante = new Restaurante();
		File ingredientes = new File("/Taller 5 Hamburguesas/data/ingredientes.txt");
		File menu = new File("/Taller 5 Hamburguesas/data/menu.txt");
		File combos = new File("/Taller 5 Hamburguesas/data/combos.txt");
		restaurante.cargarInformacionRestaurante(ingredientes, menu, combos);
		
	}
	
	private Boolean pedidosIguales(Pedido pedido1, Pedido pedido2){
		Boolean bool = false;
		if((pedido1.getNombreCliente().equals(pedido2.getNombreCliente()))
				&& (pedido1.getIdPedido() == pedido2.getIdPedido())
				&& (pedido1.getPrecioTotalPedido() == pedido2.getPrecioTotalPedido()))
				{
			bool = true;
		}
		return bool;		
	}
	
	@Test
	void testsPedidos() throws YaHayUnPedidoEnCursoException, IOException, NoHayPedidoEnCursoException {
		restaurante.iniciarPedido("César Espinosa", "Cale 127");
		Pedido pedido = new Pedido("César Espinosa", "Calle 127"); 
		assertTrue(pedidosIguales(pedido, restaurante.getPedidoEnCurso()), "El pedido en curso no es el esperado");
		assertThrows(YaHayUnPedidoEnCursoException.class, ()-> restaurante.iniciarPedido("Mateo", "Calle 100"), "Exception ya hay pedido en curso no lanzada.");
		restaurante.cerrarYGuardarPedido();
		assertEquals(null, restaurante.getPedidoEnCurso(), "Pedido en curso no actualizado.");
		assertThrows(NoHayPedidoEnCursoException.class, ()-> restaurante.cerrarYGuardarPedido(), "Exception no hay pedido en curso no lanzada.");
		assertEquals(1, restaurante.getPedidos().size(), "Número de pedidos actualizado incorrectamente.");
		assertTrue(pedidosIguales(pedido, restaurante.getPedidos().get(0)));
	}
	
	@Test
	void testGetMenuBase() {
		assertEquals(22, restaurante.getMenuBase().size(), "Hay más elementos que los cargados.");
	}
	
	@Test
	void testGetMenuCombos() {
		assertEquals(4, restaurante.getMenuCombos().size(), "Hay más elementos que los cargados.");
	}
	
	@Test
	void testGetIngredientes() {
		assertEquals(15, restaurante.getIngredientes().size(), "Hay más elementos que los cargados.");
	}
}
