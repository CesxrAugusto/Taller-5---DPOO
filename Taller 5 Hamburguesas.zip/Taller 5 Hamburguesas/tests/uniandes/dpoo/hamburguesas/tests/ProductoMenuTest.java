package uniandes.dpoo.hamburguesas.tests;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import uniandes.dpoo.hamburguesas.mundo.ProductoMenu;

class ProductoMenuTest {
	
	private ProductoMenu productoMenu;
	
	
	@BeforeEach
	void setUp() throws Exception {
		productoMenu = new ProductoMenu("Corral", 14000);
		
	}
	
	@Test
	void testGetNombre() {
        assertEquals( "Corral", productoMenu.getNombre( ), "El nombre del producto no es el esperado." );

	}
	
	@Test
	void testGetPrecio() {
        assertEquals( 14000, productoMenu.getPrecio( ), "El precio del producto no es el esperado." );
	}
	
	@Test
	void testGenerarTextoFactura() {
        assertEquals( "Corral\n            14000\n", productoMenu.generarTextoFactura() , "El texto de la factura no es el esperado." );
	}	

}
